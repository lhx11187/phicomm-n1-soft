CADDY 0.11

Website
	https://caddyserver.com

Community Forum
	https://caddy.community

Twitter
	@caddyserver

Source Code
	https://github.com/mholt/caddy
	https://github.com/caddyserver


For instructions on using Caddy, please see the docs on the
website. For a list of what's new in this version, see
CHANGES.txt.

For a good time, follow @mholt6 on Twitter.

Want to get involved with Caddy's development? We love to have
contributions! Please file an issue on GitHub to discuss a
change or fix you'd like to make, then submit a pull request
and we'll review it! Your contributions will reach millions
of people who connect to sites served by Caddy.

Extend Caddy by developing a plugin for it! Instructions on
the project wiki: https://github.com/mholt/caddy/wiki

And thanks - you're awesome!

If you think Caddy is awesome too, consider sponsoring it:
https://caddyserver.com/sponsor - and help keep Caddy free
for personal use.


---
(c) 2015-2018 Light Code Labs, LLC
